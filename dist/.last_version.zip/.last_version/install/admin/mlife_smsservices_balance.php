<?
require_once($_SERVER["DOCUMENT_ROOT"]."/bitrix/modules/mlife.smsservices/admin/mlife_smsservices_balance.php");
?>