<?
$arModuleVersion = array(
	"VERSION" => "2.2.6",
	"VERSION_DATE" => "2025-11-18 22:10:00"
);
?>