<?
$arModuleVersion = array(
	"VERSION" => "2.2.7",
	"VERSION_DATE" => "2025-11-19 05:44:00"
);
?>